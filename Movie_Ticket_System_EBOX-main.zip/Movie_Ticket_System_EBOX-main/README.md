# Movie_Ticket_System_EBOX
A console-based Java project to book movie tickets. Users can view movies, check show timings, and book or cancel tickets easily. Developed using E-Box, it demonstrates basic Java concepts like OOP, arrays, and loops for simple ticket management through command-line interaction.
